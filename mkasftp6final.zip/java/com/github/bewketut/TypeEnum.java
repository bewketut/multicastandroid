package com.github.bewketut;

/**
 * Author:  Minuit
 * Time: 2020/12/1
 * Description:
 */
public enum TypeEnum {
    OPEN,
    WEP,
    PSK,
    EAP
}
