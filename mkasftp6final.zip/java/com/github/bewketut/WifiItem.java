package com.github.bewketut;

import android.graphics.drawable.Drawable;
import android.net.wifi.ScanResult;
//import java.nio.file.Path;
/**
 * Each Row Item in our List is store here and used in our adapter
 */
final public class WifiItem  implements Comparable <WifiItem>{
	public ScanResult scanresult;
   private Drawable mImage;
   private static final String SECURITY_WEP = "WEP";
    private static final String SECURITY_WPA = "WPA";
    private static final String SECURITY_PSK = "PSK";
    private static final String SECURITY_EAP = "EAP";

    /**
     * for setting wifi access point security type
     */
    public static final String SECURITY_NONE = "NONE";

        private boolean mChecked=false;
        public WifiItem(ScanResult res,Drawable draw,boolean checked){
        	scanresult=res;
        	 mChecked=checked;
        	 mImage=draw;
        	}
        public void setwifiItem(WifiItem it){
          scanresult=it.scanresult;
          mImage=it.getmImage();
          mChecked=it.isChecked();
          }
        public void setScanRes(ScanResult res){
        	scanresult=res;
        	}
public void setChecked(boolean value) {
		this.mChecked = value;
	}

	public boolean isChecked() {
		return this.mChecked;
	}
	public Drawable getmImage() {
		return mImage;
	}
	public void setmImage(Drawable mImage) {
		this.mImage = mImage;
	
     } 
 public static String getWifiSecurityType(ScanResult result) {
        if (result.capabilities.contains("WEP")) {
            return SECURITY_WEP;
        } else if (result.capabilities.contains("WPA")) {
            return SECURITY_WPA;
        } else if (result.capabilities.contains("PSK")) {
            return SECURITY_PSK;
        } else if (result.capabilities.contains("EAP")) {
            return SECURITY_EAP;
        }
        return SECURITY_NONE;
    }

        
	/** Make PathItem comparable by its name */
	public int compareTo(WifiItem other) {
		if (this.scanresult.BSSID != null && this.scanresult.SSID!=null)
			return this.scanresult.BSSID.compareTo(other.scanresult.BSSID);
		else
			throw new IllegalArgumentException();
	}
}
