/**********************************
*****last date:Fri 23 Sep,24 June,21 June,7 May,March 2022, February 2021
**** copyright owner(author):
 Bewketu Tadilo Shibabaw
**** license: BSD (put copyright ***holder name (i.e. Bewketu Tadilo Shibabaw and signature ~bts) on  this original code or derivative  and binaries to show the copyright embedded in it on further)  ********************************************************/
package com.github.bewketut;
//import android.os.Environment;

import android.os.Build;
import android.os.Handler;
import android.graphics.drawable.Drawable;
import android.view.View;

import android.app.Activity;
import android.content.Context;

//import android.os.AsyncTask;

import java.net.*;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.StandardSocketOptions;
import java.net.SocketOptions;
import java.nio.channels.DatagramChannel;
import java.nio.channels.MembershipKey;
import java.io.FileOutputStream;
import java.io.File;
//import android.os.Build;
import java.net.DatagramPacket;
import java.io.IOException;

import java.nio.ByteBuffer;

import java.util.*;
import java.nio.channels.FileChannel;
//import java.net.SocketAddress;


import java.nio.file.Files; 
import java.nio.file.Path;
import java.nio.file.Paths; 
import static java.nio.file.StandardOpenOption.*;
import java.nio.file.OpenOption;

 //import java.nio.file.attribute.*;
final public class MulticastSender {
//private volatile Path filepath=null;
private static final String TAG = MulticastSender.class.getSimpleName();
private  static final  char BUFSIZ=8192, MBUFSIZ=BUFSIZ+3, NMUTEXFILES=256;
//	private Path testf= Paths.get("/sdcard/Download/1/vid1.3gp");
//		private	String message= new String("-c~echo hello");

	private final Context mContext;
//	private final String maddr="227.226.225.224";
	private static volatile InetAddress addr=null,switchaddr=null, addr6=null,maddr6=null;
	private static final char port=5010;
 
 //private Path fname=testf;
// private volatile Activity activity;
 
private static volatile MembershipKey mmkey=null;

private final static FileChannel[][] fcarray= new FileChannel[NMUTEXFILES][NMUTEXFILES];


private final static byte DATASNG=1,DATARPT=2,DATAPIPE=3,DATACLOSEPIPE=4,SOF=5,FOLIST=6,EOLAST=7,XOFMCAST=8, XOREADY=9;
private final static int[][] nextlen= new int[NMUTEXFILES][NMUTEXFILES];
{
for(int i=0;i<NMUTEXFILES;i++){
 for(int d=0; d< NMUTEXFILES; d++){
nextlen[i][d]=BUFSIZ; fcarray[i][d]=null;
}}
 }
private static volatile Thread  receiverThread=null, senderThread=null;
   private static volatile InetAddress group=null;

	private  static volatile  NetworkInterface ni=null;
private static volatile String mappedv6addr;
private  volatile	int ext=0,nfiles1=0,nfilescount=0;
private static final  String cwdir=new String("/sdcard/m4power6/");
private final static   Path cwdpath= Paths.get(cwdir);

public static volatile boolean run=false;
//  private volatile String message =null;
public static volatile InetAddress peern=null;
//private volatile int netprefixlen;
private  volatile Drawable drawable=null;
 private  volatile PathItem pathitem=null;

private volatile PathItemListener pitl;
private 		byte rcvflag=0;
private final static byte on=1, off=0;
 private static volatile boolean switchflag=false;

public MulticastSender(final Drawable draw,final Context con, PathItemListener pitl){ 
	  //testf.resolveSibling("temp.txt");
this.pitl=pitl;
drawable=draw;
mContext=con;
	try{ 
	   if(Files.notExists(cwdpath)){
   //txt.setText("folder not exists");
   Files.createDirectory(cwdpath);
   }

   //	 filebuffer=Files.readAllBytes(fname);size=filebuffer.length;
  }  
	catch(IOException ex){}
 initAddress();
}
//public synchronized PathItem getPathItem(){
//pitemchanged=false;
//return pathitem;
//}
interface PathItemListener {
public void onpitemchanged(PathItem it);
}
public void initAddress(){
try{	addr=getLanAddress();
 ni=NetworkInterface.getByInetAddress(addr);
//netprefixlen=ni.getInterfaceAddresses().get(0).getNetworkPrefixLength();
maddr6=InetAddress.getByName("FF12::BEED:BEED:BEED");
 group =Inet6Address.getByAddress(maddr6.getHostAddress(),maddr6.getAddress(),ni);
byte[] routeraddress=addr.getAddress();
routeraddress[3]=1;
//for(int i=((netprefixlen)/8)-1 ; i <3;i++) routeraddress[i]=0; 
 if(bytencmp(addr.getAddress(),0, routeraddress, 0, 4) && addr.getHostAddress().equals("192.168.43.1")) switchflag=true;  
 else switchaddr=  InetAddress.getByAddress(routeraddress);

mappedv6addr ="::ffff:"+addr.getHostAddress();
  InetAddress mappedv6=Inet6Address.getByName(mappedv6addr);
 //InetAddress.getByName(maddr); 
addr6=Inet6Address.getByAddress(mappedv6.getHostAddress(),mappedv6.getAddress(),ni);

//addr6=mappedv6;
 }  
	catch(IOException ex){}
 
}
public  synchronized void receiveFiles(View v){

initAddress();
final byte[] buffer = new byte[MBUFSIZ],filebytes=new byte[300]; final ByteBuffer buf=ByteBuffer.wrap(buffer),fbuffer=ByteBuffer.wrap(buffer,0,BUFSIZ);
buffer[MBUFSIZ-2]=buffer[MBUFSIZ-1]=buffer[MBUFSIZ-3]=0;run=true;
final DatagramChannel dc=openmdc();
final Handler handler = new Handler();

final Runnable task= new Runnable() { 
				 	 @Override public void run() { 
				 pitl.onpitemchanged(pathitem) ;//txt.setText("sent the file "+filepath.getFileName()) ; 
} };
	 receiverThread =new Thread(new Runnable() {

		@Override public void run()
		{
	File filen1=null,filen2=null, filen3=null;			 
	String file1=null,str1=null,str2=null;
  	boolean res=false; InetSocketAddress inetSock= (!switchflag)?new InetSocketAddress(switchaddr,port):null;
String ext=null; byte fflag=0;
int files2write=0,nlist=0, grpn=0,filen=0,ind=0;
  int bufpos=0;
		try
			{ 
 

/*buffer[0]=(switchflag)?on:off;
byteCopy(buffer,1,"XOFREADY".getBytes(),0,8); buf.limit(10);

 
 dc.send(buf,inetSock);
 buf.flip(); buf.limit(MBUFSIZ); buf.clear();
*/
				while(run){
						dc.receive(buf);
					bufpos=buf.position();
				
					if( bytstrncmp(buffer,1,"XOFMCAST",8)){
pathitem=new PathItem("Received XOMCAST  ",null,"ip address request",1,drawable,false,true);
inetSock = new InetSocketAddress(InetAddress.getByName((new String(byteCopy(filebytes,0,buffer,10,32))).intern().trim()),port);
handler.post(task);	
buf.flip();		buf.limit(10); 
 byteCopy(buffer,1,"XOFREADY".getBytes(),0,8); buffer[0]=(switchflag)?on:off;
 dc.send(buf,inetSock);
 buf.flip(); buf.limit(MBUFSIZ);
continue;
 }
					if((bufpos+1)>=MBUFSIZ) bufpos=0;
					else continue;
						
								grpn=(buffer[MBUFSIZ-2]&     0xff);filen=(buffer[MBUFSIZ-1]&0xff);
fflag=buffer[MBUFSIZ-3];
buf.flip(); 
			if(grpn>0 && filen>0){

	if(fflag==SOF ||bytstrncmp(buffer,1,"S0F!",4)){

		byteCopy(filebytes,0,buffer,6,300);

file1=(new String(filebytes)).intern().trim();
/*ind= file1.lastIndexOf(".");
ext=file1.substring(ind).trim().intern();
if(ext.length()>5) ext=ext.substring(0,5);
file1=file1.substring(0,ind).trim().intern()+ext;
*/
filen2 = new File(cwdir,file1.trim());

if(filen2.exists()) {
 ind= file1.lastIndexOf(".");
 if(ind>0){
	str1 =  file1.substring(0,ind); str2= file1.substring(ind);
file1=str1+"_01"+str2;
 }
 else  file1+= "_01";

}

pathitem=new PathItem("Started receiving  "+file1+" on channel"+grpn+" file "+filen,null,"Downloading...",1,drawable,false,true);
handler.post(task);
	filen3= new File(cwdir,file1.trim());
fcarray[grpn][filen]= (new FileOutputStream(filen3)).getChannel();
if(fcarray[grpn][filen]==null){
file1="receivedFile"+ext;
fcarray[grpn][filen]= (new FileOutputStream(cwdir+file1)).getChannel();
}
if(fcarray[grpn][filen]!=null && nlist==0)
files2write++;

		}		
 else if(fflag==EOLAST || bytstrncmp(buffer,1,"EOL",3))
{
	nextlen[grpn][filen]=((int)(buffer[4] & 0xff)*256) + ((int)(buffer[5] & 0xff) );
    }
else if(fflag==FOLIST || bytstrncmp(buffer,0,"FOList",6)){
nlist=(buffer[8] & 0xff)*256+(buffer[7] & 0xff);
files2write+=nlist;
nlist=files2write;
pathitem=new PathItem("Will download a total of "+nlist+" files!!",null,cwdir,1,drawable,false,true);
handler.post(task);
}
    else	if(fflag==DATASNG && files2write>0){ 

 if(nextlen[grpn][filen]!=BUFSIZ){
fbuffer.limit(nextlen[grpn][filen]);

    		writen(fbuffer,nextlen[grpn][filen],fcarray[grpn][filen]);  fbuffer.flip();

fbuffer.limit(BUFSIZ);
    		
fcarray[grpn][filen].close();
fcarray[grpn][filen]=null;
pathitem=new PathItem("Finished receiving file on  channel"+grpn+" file"+filen +" and just closed file",null,cwdir,1,drawable,false,true);
handler.post(task);
nextlen[grpn][filen]=BUFSIZ;

if(files2write==1){
/*pathitem=new PathItem("Finished receiving all "+nlist+" file"+((nlist>1)?"s":"")+"!!",null,cwdir,1,drawable,false,true);
handler.post(task);*/
nlist=0;
}
files2write--;

    			}
		else 
	{
		writen(fbuffer,BUFSIZ,fcarray[grpn][filen]);

			fbuffer.flip() ;
		}

		}
		}
//buffer[MBUFSIZ-1]=buffer[MBUFSIZ-2]=0;filen=grpn=0;
buf.clear();
				}
dc.close();
	}catch(IOException ex){}
  	

} });
receiverThread.start();
	
  }

  
public synchronized void setRcvFlag(byte recvf){
rcvflag=recvf;
}
public synchronized void setBufferId(byte[] buffer,byte id1,byte id2, byte id3){
	buffer[MBUFSIZ-3]=id1;
	buffer[MBUFSIZ-2]=id2;
	buffer[MBUFSIZ-1]=id3;
}

//public synchronized void receiveFiles(){
//receiverThread=null;
//receiveFile();


//}
public static synchronized void stopReceiver(){
run=false;
if(receiverThread!=null){
//receiverThread.stop();
receiverThread=null;
}else if(senderThread!=null){
senderThread=null;
}
}

public static synchronized String getAddr(){
//if(message==null) return "geeps";
return addr.getHostAddress();
}
public static boolean isValidIp(boolean hostf){

 String address=getLanAddress().getHostAddress();
 if(address==null || bytstrncmp(address.getBytes(),0, "127", 3) || bytstrncmp(address.getBytes(),0, "0", 1)) return false;
else if(hostf) return address.equals("192.168.43.1");
return true; 
}
public static boolean isSwitch(){return switchflag;}

public  synchronized void receiveAddr(View v){
initAddress();
final byte[] buffer = new byte[MBUFSIZ];	
final ByteBuffer buf=ByteBuffer.wrap(buffer);
final byte[] straddrbyte =addr.getHostAddress().getBytes();
final int addrlen = straddrbyte.length;
final Handler handler = new Handler();
final Runnable task= new Runnable() { 
				 	 @Override public void run() { 
				 pitl.onpitemchanged(pathitem) ; 
} };
final DatagramChannel	 dtgc=openmdc();
receiverThread = new Thread(new Runnable() {
		
		@Override public void run()
		{
		run=true; 
		 InetSocketAddress inetSock=null;
		 
  InetSocketAddress sender=null;
			try
			{
		 	  inetSock=new
       InetSocketAddress(group,port);


   while(!bytstrncmp(buffer,1, "XOFREADY", 8) && run){
buffer[MBUFSIZ-3]=XOFMCAST; buffer[0]=(switchflag)?on:off;byteCopy(buffer,1,"XOFMCAST".getBytes(),0,8);
byteCopy(buffer,10,straddrbyte,0,addrlen);
buffer[10+addrlen]= buffer[9]='\0';   
 sendn(buf,dtgc,inetSock,MBUFSIZ);
    buf.flip();
try{Thread.sleep(100);} catch(InterruptedException ex){}
buf.limit(10); sender=(InetSocketAddress)dtgc.receive(buf);
  buf.flip();buf.limit(MBUFSIZ);
  }


//sockaddr= sender;
peern=sender.getAddress();
pathitem=new PathItem("Determined ip of receiver "+ sender.getAddress().getHostAddress(),null,"now sending file/s"
 ,1,drawable,false,true);
handler.post(task);

 
dtgc.close();
run=false;
        } 
catch (IOException e) { e.printStackTrace(); }
//handler.post 

} });
receiverThread.start();

}
public static DatagramChannel openmdc(){
	try{
DatagramChannel	dc = DatagramChannel.open(StandardProtocolFamily.INET6).bind(new InetSocketAddress(addr6,port)).setOption(StandardSocketOptions.SO_REUSEADDR, true).setOption(StandardSocketOptions.IP_MULTICAST_IF, ni).setOption(StandardSocketOptions.SO_RCVBUF,(int)MBUFSIZ);

dc.configureBlocking(false);
mmkey=dc.join(group,ni);

return dc;	
	}
	catch(IOException ex){}
	return null;
}
public static synchronized DatagramChannel openmdc2(){
	try{
		DatagramChannel dc = DatagramChannel.open(StandardProtocolFamily.INET6).bind(null).setOption(StandardSocketOptions.SO_REUSEADDR, true).setOption(StandardSocketOptions.IP_MULTICAST_TTL,1).setOption(StandardSocketOptions.IP_MULTICAST_LOOP,true).setOption(StandardSocketOptions.IP_MULTICAST_IF, ni).setOption(StandardSocketOptions.SO_SNDBUF,(int)MBUFSIZ);
dc.configureBlocking(true);
//bind(new InetSocketAddress(addr,port)).
return dc;
	}catch(IOException ex){}
	return null;
}
public 
synchronized void sendFiles( final List<PathItem> pathitemlist,View v)
{
//initAddress();

final byte[] FOList= new byte[MBUFSIZ];
final int nfiles;
if(pathitemlist!=null && (pathitemlist.size())>0)
nfiles=pathitemlist.size();
else {nfiles=0;return;}

 nfiles1=nfiles;
final FileChannel[] fc= new FileChannel[nfiles];
final ByteBuffer folist= ByteBuffer.wrap(FOList);	
final	 byte[] SOF1= new byte[MBUFSIZ],EOL=new byte[MBUFSIZ], buffer = new byte[MBUFSIZ];
final ByteBuffer[] sof= new ByteBuffer[nfiles],eol=new ByteBuffer[nfiles],buf=new ByteBuffer[nfiles],fbuffer=new ByteBuffer[nfiles];
for(int i=0; i < nfiles; i++){
sof[i]=ByteBuffer.wrap(SOF1);
eol[i]=ByteBuffer.wrap(EOL);
buf[i]=ByteBuffer.wrap(buffer);
fbuffer[i]=ByteBuffer.wrap(buffer,0,BUFSIZ);
}
final DatagramChannel dtgc=openmdc2(); 	 
final Handler handler = new Handler();
final Runnable task= new Runnable() { 
				 	 @Override public void run() { 
				 pitl.onpitemchanged(pathitem) ;
} };
 senderThread = new Thread(new Runnable() {
		
			
		@Override public void run()
		{
			 
              long ntimes=0, size=0;
            char rem=0;	
Path	filep=null;
 int k=0, i=0;
byte filen=0,grpn=0,datapipe=0, r=1;
			 InetSocketAddress inetSock=null;
//try{Thread.sleep(300);} catch(InterruptedException ex){}
		try	{
//	 pathitem=new PathItem("Using unicast address "+peern,null,"sending..."+size,size,drawable,false,true);
//handler.post(task);

   if(switchflag){
while(peern==null ){ try{ Thread.sleep(200);}
catch(InterruptedException e){ }
}
 inetSock=new InetSocketAddress(peern,port);

pathitem=new PathItem("Using address:"+peern,null,"sending..."+size,size,drawable,false,true);
handler.post(task);
}
  else   	  inetSock=new
     InetSocketAddress(group,port);
    
if(nfiles1>0){
byteCopy(FOList,0,"FOList".getBytes(),0,6);
FOList[8]=(byte)(nfiles1/256); FOList[7]=(byte)(nfiles1%256);
FOList[MBUFSIZ-2]=1;FOList[MBUFSIZ-1]=1;
FOList[MBUFSIZ-3]=FOLIST;
sendn(folist,dtgc,inetSock,MBUFSIZ);
folist.flip(); 
}

 for(PathItem pathit : pathitemlist){
    copySof(SOF1,pathit.getFilePath(),grpn,filen,datapipe);
 filen=SOF1[MBUFSIZ-1];grpn=SOF1[MBUFSIZ-2];
SOF1[MBUFSIZ-3]=SOF;

  size=pathit.getFileSize1();
//size=fc.size();
   	 ntimes=size/BUFSIZ;
   	 rem=(char)(size%BUFSIZ);
fc[k]=openread(pathit.getFilePath());
 



 sendn(sof[k],dtgc,inetSock,MBUFSIZ);
sof[k].flip(); 


  
pathitem=new PathItem("Sending "+pathit.getFileName(),null,"sending..."+size,size,drawable,false,true);
handler.post(task);

 
 for(i=0; i< ntimes; i++){
 	readn(fbuffer[k],i*BUFSIZ,BUFSIZ,fc[k]);

 	  fbuffer[k].flip();
 
 
buffer[MBUFSIZ-1]=filen;
  buffer[MBUFSIZ-2]=grpn;
   buffer[MBUFSIZ-3]=DATASNG;
	 sendn(buf[k],dtgc,inetSock,MBUFSIZ);  	
	 buf[k].flip();

 } 
copyEOL(EOL,filen,grpn,datapipe,size); 
	 
  EOL[MBUFSIZ-3]=EOLAST;
 sendn(eol[k],dtgc,inetSock,MBUFSIZ);	 
eol[k].flip();
	eol[k].clear(); 

	readn(fbuffer[k],i*BUFSIZ,rem,fc[k]); 

buffer[MBUFSIZ-1]=filen;
  buffer[MBUFSIZ-2]=grpn;
   buffer[MBUFSIZ-3]=DATASNG;
			 sendn(buf[k],dtgc,inetSock,MBUFSIZ);
 buf[k].flip();
fbuffer[k].position(0);fbuffer[k].clear();

pathitem=new PathItem("Finished Sending "+pathit.getFileName(),null,"sent "+size,1,drawable,false,true);
handler.post(task);
fc[k].close();sof[k]=eol[k]=buf[k]=fbuffer[k]=null;
fc[k]=null;
k++;

}
pathitem=new PathItem("Finished Sending all "+ nfiles+" files!!",null,"to receiver",1,drawable,false,true);
handler.post(task); 
  dtgc.close();
 } 
catch (IOException e) { e.printStackTrace(); }

} });
	senderThread.start();
}

public 
synchronized void sendFile(final PathItem pathit,final int nfiles,View v)
{
final Path	filep=pathit.getFilePath();
final byte[] FOList= new byte[MBUFSIZ];


byte filentmp=0,grpntmp=0,dpiptmp=1;
final byte[] SOF1= new byte[MBUFSIZ],EOL=new byte[MBUFSIZ];
  copySof(SOF1,filep,filentmp,grpntmp,dpiptmp);
final byte filen=SOF1[MBUFSIZ-1],grpn=SOF1[MBUFSIZ-2],datapipe=SOF1[MBUFSIZ-3];
final ByteBuffer
sof=ByteBuffer.wrap(SOF1),eol=ByteBuffer.wrap(EOL);	final ByteBuffer folist= ByteBuffer.wrap(FOList);
final byte[] buffer = new byte[MBUFSIZ];
buffer[MBUFSIZ-1]=SOF1[MBUFSIZ-1];
buffer[MBUFSIZ-2]=SOF1[MBUFSIZ-2]; buffer[MBUFSIZ-3]=SOF1[MBUFSIZ-3]=SOF;
 final ByteBuffer buf=ByteBuffer.wrap(buffer),fbuffer=ByteBuffer.wrap(buffer,0,BUFSIZ);
final DatagramChannel dtgc=openmdc2(); 	 
final Handler handler = new Handler();
final Runnable task= new Runnable() { 
				 	 @Override public void run() { 
				 pitl.onpitemchanged(pathitem) ;//txt.setText("sent the file "+filepath.getFileName()) ; 
} };
final	Thread thread = new Thread(new Runnable() {
		
		@Override public void run()
		{final FileChannel fc;
			
              long ntimes=0, size=0;
            char rem=0;	byte r=0;
			 InetSocketAddress inetSock=null;
			try
			{
	 
    //	 pathitem=new PathItem("Using unicast address "+peern,null,"sending..."+size,size,drawable,false,true);
//handler.post(task);

//    if(switchflag){

 inetSock=new InetSocketAddress(peern,port);

pathitem=new PathItem("Using unicast address "+peern,null,"sending..."+size,size,drawable,false,true);
handler.post(task);
//}
      
 
  fc=openread(filep);
  size=pathit.getFileSize1();

   	 ntimes=size/BUFSIZ;
   	 rem=(char)(size%BUFSIZ);

  //fc=openread(fname);    
if(nfiles>0){
byteCopy(FOList,0,"FOList".getBytes(),0,6);
FOList[8]=(byte)(nfiles/256); FOList[7]=(byte)(nfiles%256);
FOList[MBUFSIZ-2]=1;FOList[MBUFSIZ-1]=1;
sendn(folist,dtgc,inetSock,MBUFSIZ);
folist.flip(); 
nfiles1=nfiles;
}
//if(rcvflag!=0){

 sendn(sof,dtgc,inetSock,MBUFSIZ);
sof.flip(); 

//try{Thread.sleep(5);} catch(InterruptedException ex){}

//}
  int i=0;
pathitem=new PathItem("Sending "+filep.getFileName(),null,"sending..."+size,size,drawable,false,true);
handler.post(task);

 for(i=0; i< ntimes; i++){
 	readn(fbuffer,i*BUFSIZ,BUFSIZ,fc);

 	  fbuffer.flip();

  for(r=1;r<3;r++){
buffer[MBUFSIZ-1]=filen;
  buffer[MBUFSIZ-2]=grpn;
   buffer[MBUFSIZ-3]=r;
	 sendn(buf,dtgc,inetSock,MBUFSIZ);
	  	
	 buf.flip();
 } }
copyEOL(EOL,filen,grpn,datapipe,size); 
	 //buf.put(buffer);buf.flip();
//	EOL[MBUFSIZ-1]=filen;
 // [MBUFSIZ-2]=grpn;
   EOL[MBUFSIZ-3]=EOLAST;

 	 sendn(eol,dtgc,inetSock,MBUFSIZ);	 
	
	eol.clear(); 	 
	readn(fbuffer,i*BUFSIZ,rem,fc); 
 	  //	byteCopy(buffer,0,filebuffer,(i*BUFSIZ),rem); //fbuffer.flip(); //
//	for(r=1;r<3;r++){
buffer[MBUFSIZ-1]=filen;
  buffer[MBUFSIZ-2]=grpn;
   buffer[MBUFSIZ-3]=DATASNG;
			 sendn(buf,dtgc,inetSock,MBUFSIZ);
 buf.flip();
fbuffer.flip();
fbuffer.limit(BUFSIZ);

fbuffer.position(0);fbuffer.clear();
//}
fc.close();
dtgc.close(); 
pathitem=new PathItem("Finished Sending "+filep.getFileName(),null,"sent "+size,1,drawable,false,true);
handler.post(task);
nfilescount++;
if(nfilescount==nfiles1 && nfiles1> 0){
pathitem=new PathItem("Finished Sending all "+ nfiles1+" files!!",null,"to receiver",1,drawable,false,true);
handler.post(task);
nfilescount=nfiles1=0;
}
     } 
catch (IOException e) { e.printStackTrace(); }

} });
	thread.start();
}
public static boolean bytstrncmp(byte[] bytes,int st1, String str, int len){
	return bytencmp(bytes,st1,str.getBytes(),0,len);
}
public static boolean bytencmp(byte[] bytes1,int st1, byte[] bytes2, int st2,int n){
	for(int i=0; i < n; i++)
	if((bytes1[st1+i]-bytes2[st2+i])!=0) return false;
	return true;
}

public static synchronized void sendn(ByteBuffer buff, DatagramChannel dc,InetSocketAddress so,int len){
	int tt=0;
		
	try{
	int nsent=0;	while((nsent=dc.send(buff,so))!=-1){
		tt+=nsent;
		if(tt>=len)
/*try{Thread.sleep(5);} catch(InterruptedException ex){}*/
 break;
	
	}
} catch(IOException ex){}	

}
/*
public static synchronized int receiven2( DatagramSocket dc1,byte[] buf2,int len){
	int tt=0;
	byte[] buf3;	 
	try{
	int nrec=0;	buf3= new byte[len];
	  mpacket= new DatagramPacket(buf3,len);
	  //rsock.setSoTimeout(10);
while(true){
	dc1.receive(mpacket);
	nrec=mpacket.getLength();
	byteCopy(buf2,tt,buf3,0,nrec);
	tt+=nrec;
		buf3= new byte[tt];
	mpacket= new DatagramPacket(buf3,len-tt);
	if(tt>=len) 
		break;
		}
	}catch(IOException ex){}	
return tt;
}
*/
public static synchronized SocketAddress receiven( DatagramChannel dc1,ByteBuffer buf2,int len){
	
		 
	try{
	int nrec=0;	
SocketAddress clientAddress;
while((clientAddress=dc1.receive(buf2))!=null){
	nrec=buf2.position(); 
	if(nrec+1>=len)
		return clientAddress;}
	}catch(IOException ex){}	
return null;
}
private static synchronized void copyEOL(byte[] EOL,byte filen,byte grpn, byte datapipe,long fileSize){
	char rem=0;
 byte rem1,rem2;

EOL[0]=filen;
EOL[1]='E'; EOL[2]='O'; EOL[3]='L'; EOL[6]=grpn;
EOL[7]='\0'; 
EOL[MBUFSIZ-1]=filen;
EOL[MBUFSIZ-2]=grpn;
EOL[MBUFSIZ-3]=datapipe;

	 rem=(char)(fileSize%BUFSIZ);
	 rem1=(byte)(rem/256); rem2=(byte)(rem%256);

	 EOL[4]= rem1; EOL[5]=rem2;
	 

}
public static synchronized int readn(ByteBuffer readbuffer, long pos,int length,FileChannel fch){
	int tt=0;
		//readbuffer.flip();
		
	try{
	int nread;	while((nread=fch.read(readbuffer,pos))!=-1){
		tt+=nread;
		if(tt>=length) break;
	
	}
	//readbuffer.flip();

	return tt;
} catch(IOException ex){}	
return -1;
}

public static synchronized int writen(ByteBuffer wbuffer, int length,FileChannel fch){
	int tt=0;
		//readbuffer.flip();
		
	try{
	//	fch.write(wbuffer,0,length);
	int nw;	while((nw=fch.write(wbuffer))>0){
		tt+=nw;
		if(tt>=length) break;
	
	}
	//readbuffer.flip();

	return tt;
} catch(IOException ex){}	
return -1;
}
/*
public synchronized  int writen2(byte[] wbuffer, int length,OutputStream fch){
	
		//readbuffer.flip();
		
	try{
		fch.write(buffer,0,length);
int nw;	while((nw=fch.write(wbuffer,tt,length-tt))!=-1){
		tt+=nw;
		if(tt>=length) break;
	
	}
	//readbuffer.flip();

	return 0;
} catch(IOException ex){}	
return -1;
}
*/
public static synchronized  FileChannel openread(Path path){
	try {
		 
		return FileChannel.open(path);
		}
catch(IOException ex){}
return null;
}
public static synchronized FileChannel openwrite(Path filenew){
	try{
		/*
   else    txt.setText("folder exists");*/
    //   file=file+filenew;
    
return  FileChannel.open(filenew,CREATE,WRITE,TRUNCATE_EXISTING);
}	catch(IOException ex){}
return null;
}

private static synchronized  void copySof(byte[] filename, Path path, byte filen, byte grpn, byte datapipe){
byte[]	 fname1= path.getFileName().toString().getBytes();
byte[] fullpath= path.toString().getBytes();
byte fileround=(byte)(fname1[0] + fname1[fname1.length-(fname1.length/2)] - fname1[fname1.length-(fname1.length/3)]);
byte filehash= (byte)(fileround%NMUTEXFILES);  
byte fileround_userchannel=(byte)(fullpath[0] + fullpath[1]-fullpath[2]+ fullpath[(fullpath.length/2)] - fullpath[(fullpath.length/3)] +
fullpath[(fullpath.length/4)] - fullpath[(fullpath.length/5)]+ fullpath[3*(fullpath.length/4)] - fullpath[4*(fullpath.length/5)]);
byte userchannel= (byte)(fileround_userchannel%NMUTEXFILES);

filename[1]='S'; filename[2]='0'; filename[3]='F';filename[4]='!';
filename[0]=filehash;
filename[5]=userchannel;
 filename[6]='\0';

filename[MBUFSIZ-3]=datapipe;
filen=filename[MBUFSIZ-1]=filehash;
grpn=filename[MBUFSIZ-2]=userchannel;
byteCopy(filename,6,fname1,0,fname1.length);
for(int i=6+fname1.length; i< 310; i++)
filename[i]='\0';




}
   

           
 /*    
public void sendFiles() throws IOException {
try{
	 arrayCopy(msg,msgbytes);
hi =new DatagramPacket(msg, msg.length,group, 5010);
s=new MulticastSocket(5010);
	  group = InetAddress.getByName("227.226.225.224"); 
	  	s.setTimeToLive(1) ;
	s.setLoopbackMode(true);
	
 	
	 s.send(hi); 
	  txt.setText("sent message: "+NetworkInterface.getByInetAddress(getLanAddress()));
	  //s.close();
	}
	catch( IOException ex){}
}
*/
public static synchronized InetAddress getLanAddress()  {
      InetAddress candidateAddress = null; InetAddress inetAddr =null;
    
      try{
        // Iterate all NICs (network interface cards)...
        for (Enumeration ifaces = NetworkInterface.getNetworkInterfaces(); ifaces.hasMoreElements();) {
            NetworkInterface iface = (NetworkInterface) ifaces.nextElement();
            // Iterate all IP addresses assigned to each card...
            for (Enumeration inetAddrs = iface.getInetAddresses(); inetAddrs.hasMoreElements();) {
                 inetAddr = (InetAddress) inetAddrs.nextElement();
                if (!inetAddr.isLoopbackAddress()) {

                    if (inetAddr.isSiteLocalAddress()) {
                        // Found non-loopback site-local address. Return it immediately...
                        
                        return inetAddr;
                    }
                    else if (candidateAddress == null) {
                        // Found non-loopback address, but not necessarily site-local.
                        // Store it as a candidate to be returned if site-local address is not subsequently found...
                        candidateAddress = inetAddr;
                        // Note that we don't repeatedly assign non-loopback non-site-local addresses as candidates,
                        // only the first. For subsequent iterations, candidate will be non-null.
                    }
                }
            }
        }
        if (candidateAddress != null) {
            // We did not find a site-local address, but we found some other non-loopback address.
            // Server might have a non-site-local address assigned to its NIC (or it might be running
            // IPv6 which deprecates the "site-local" concept).
            // Return this non-loopback candidate address...
            
            return candidateAddress;
        }
        // At this point, we did not find a non-loopback address.
        // Fall back to returning whatever InetAddress.getLocalHost() returns...
        InetAddress jdkSuppliedAddress = InetAddress.getLocalHost();
        if (jdkSuppliedAddress == null) {
            throw new UnknownHostException("The JDK InetAddress.getLocalHost() method unexpectedly returned null.");
        }
        return jdkSuppliedAddress;
    }
    catch (Exception e) {
    	/*
        UnknownHostException unknownHostException = new UnknownHostException("Failed to determine LAN address: " + e);
        unknownHostException.initCause(e);
        throw unknownHostException;
  */  }
  return inetAddr;
}


public synchronized static byte[] byteCopy( byte[] dest, int st, byte[] src, int st2, int length){
byte [] thebytes= new byte[length];
	for( int i=0;i< length; i++)
	thebytes[i]=dest[st+i]=src[st2+i];
 
return thebytes;
}
}
