package com.github.bewketut;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.net.TetheringManager;
import android.net.TetheringManager.StartTetheringCallback;
import android.net.wifi.SoftApConfiguration;
import android.content.pm.PackageManager;
//import com.android.server.pm.PackageManagerService;
import android.os.Build;
import android.os.Bundle;
import android.os.Binder;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.app.Activity;
import android.app.ActivityManager;
//import com.android.dx.stock.ProxyBuilder;
import android.graphics.drawable.Drawable;
/*import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
*/
final public class HotspotManager{
private final static String TAG = "Hotspot";
private String apname=null,password=null;
private  volatile Drawable drawable=null;
 private  volatile PathItem pathitem=null;
private volatile PathItemListener pitl;
private final Context mContext;
private WifiManager wifim;
private Boolean onoff=false;
private static int hscount=0;
public HotspotManager(Context mCon,Drawable pic, PathItemListener pit){
mContext=mCon; drawable=pic; pitl=pit;

}
interface PathItemListener {
public void onpitemchanged(PathItem it);
}
public void setSwitchon(Boolean val){
 onoff=val;
}
public void configureHotspot(String name, String password) {
      SoftApConfiguration.Builder b= new SoftApConfiguration.Builder();
  WifiConfiguration apConfig=null;
//=
 //setconfig();
/*b.setSsid(name).setWpa2Passphrase(password).build();*/

        //apConfig.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
//wifim.setSoftApConfiguration(apConfig);
/*
        try {
            Method setConfigMethod = wifim.getClass().getMethod("getWifiApConfiguration", WifiConfiguration.class);
            apConfig = (WifiConfiguration) setConfigMethod.invoke(wifim, apConfig);
        //    Log.d(TAG, "setWifiApConfiguration - success? " + status);
        } catch (Exception e) {
            Log.e(TAG, "Error in configureHotspot");
            e.printStackTrace();
        }
name=     apConfig.SSID;
password=apConfig.preSharedKey;
*/
    }
 
public  void setWiFiApEnable(Context mContxt, Boolean val) {
       

    if (Settings.System.canWrite(mContxt)) { 
     if(hscount==0){
 onoff=val; hscount=1;}
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
TetheringManager tm= null;
 
 
        if (onoff){
onoff=false;
configureHotspot("mkasfudp6","12345678");
     pathitem=new PathItem("wifi hotspotname & password: please check your hotspot setting.",null,"Starting wifi hotspot.to TURN ON/OFF: CLICK START MGROUP",1,drawable,false,true);              
pitl.onpitemchanged(pathitem);      
            StartTetheringCallback callback= new StartTetheringCallback(){
                @Override
                public void onTetheringStarted() {Log.d(TAG, "onTetheringStarted");
                }
 
                @Override
                public void onTetheringFailed(int x) {
 Log.d(TAG, "onTetheringFailed");
                }
            };
           tm.startTethering(null,null,callback);
        }else{ onoff=true;
            tm.stopTethering(1);  
 }
  }
else    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
  ConnectivityManager  mConnectivityManager= (ConnectivityManager) mContxt.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (onoff) { onoff=false;
//configureHotspot("mkasfudp6","12345678");
     pathitem=new PathItem("wifi hotspotname & password: please check your hotspot setting.",null,"Starting wifi hotspot.to TURN ON/OFF: CLICK START MGROUP",1,drawable,false,true);              
pitl.onpitemchanged(pathitem);       mConnectivityManager.startTethering(ConnectivityManager.TETHERING_WIFI, false, new ConnectivityManager.OnStartTetheringCallback() {
                @Override
                public void onTetheringStarted() {
    
  Log.d(TAG, "onTetheringStarted");
                    // Don't fire a callback here, instead wait for the next update from wifi.
                }
 
                @Override
                public void onTetheringFailed() {
                 Log.d(TAG, "onTetheringFailed");
                  // TODO: Show error.
                }
            });
        }
 else { onoff=true;
            mConnectivityManager.stopTethering(ConnectivityManager.TETHERING_WIFI);}
        
 }
      }      else {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + mContxt.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
               mContxt.startActivity(intent);
            }
       
 }   
/**
 * see {@link WifiManager#getWifiApConfiguration()}
 * @return soft access point configuration
 * @throws SecurityException if the caller does not have permission to retrieve the softap
 * config
 */

//@Override
public void setconfig() {
    enforceAccessPermission(); // access permission check
    int uid = Binder.getCallingUid();
    // only allow Settings UI to get the saved SoftApConfig
         if (!checkConfigOverridePermission(uid)) { // override permission check
        // random apps should not be allowed to read the user specified config
        throw new SecurityException("App not allowed to read or update stored WiFi Ap config "+ "(uid = " + uid + ")");
    }
    //mLog.trace("getWifiApConfiguration uid=%").c(uid).flush();
   // return wifim.getWifiApConfiguration();
}
/*@RequiresApi(api = Build.VERSION_CODES.O)
    public  void setHotspotOnPhone(Context mContext, boolean isEnable) {
 //TetheringManager.TetheringRequest.Builder b;
}*/
private void enforceAccessPermission() {
    mContext.enforceCallingOrSelfPermission(android.Manifest.permission.ACCESS_WIFI_STATE,
            "WifiService");
}

/**
 * Checks if the app has the permission to override Wi-Fi network configuration or not.
 *
 * @param uid uid of the app.
 * @return true if the app does have the permission, false otherwise.
 */
public boolean checkConfigOverridePermission(int uid) {
    try
{

        int permission = getOverrideWifiConfigPermission(uid);
        return (permission == PackageManager.PERMISSION_GRANTED);
    } catch (Exception e) {
       // Log.err("Error checking for permission: %").r(e.getMessage()).flush();
        return false;
    }
}

/**
 * Determines if the caller has the override wifi config permission.
 *
 * @param uid to check the permission for
 * @return int representation of success or denied
 * @throws RemoteException
 */

public int getOverrideWifiConfigPermission(int uid)
 //throws RemoteException
 {
    return ActivityManager.
checkUidPermission(
            android.Manifest.permission.OVERRIDE_WIFI_CONFIG, uid);
}  
}
