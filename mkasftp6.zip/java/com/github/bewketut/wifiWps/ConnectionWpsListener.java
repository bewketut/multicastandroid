package com.github.bewketut.wifiWps;

public interface ConnectionWpsListener {
    void isSuccessful(boolean isSuccess);
}
