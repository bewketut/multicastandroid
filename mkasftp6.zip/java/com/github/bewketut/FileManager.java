/**********************************
*****last date:Fri 23 Sep,24 June,21 June,7 May,March 2022, February 2021
**** copyright owner(author):
 Bewketu Tadilo Shibabaw
**** license: BSD (put copyright ***holder name (i.e. Bewketu Tadilo Shibabaw and signature ~bts) on  this original code or derivative  and binaries to show the copyright embedded in it on further)  ********************************************************/
package com.github.bewketut;
import android.app.Activity;
//import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
//import androidx.annotation.RequiresApi;

//import android.app.ActionBar;
//import android.app.Fragment;
//import android.content.Context.ContextCompat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
//import android.view.View;
//import android.view.ViewGroup;
import android.Manifest;
//import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
//import android.net.wifi.SupplicantState;
//import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.view.ContextThemeWrapper;
//import android.content.Intent;
import android.provider.Settings;
//import android.view.View.OnClickListener;
import android.net.Uri;
import android.app.AlertDialog;
//import android.net.wifi.WifiManager;
import android.widget.TextView;
//import android.widget.ImageView;
import android.widget.Button;
import android.widget.Toast;
import android.graphics.drawable.Drawable;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.EditText;
import android.widget.ListView;

import com.github.bewketut.wifiDisconnect.DisconnectionErrorCode;
import com.github.bewketut.wifiDisconnect.DisconnectionSuccessListener;
import com.github.bewketut.wifiConnect.ConnectionErrorCode;

import com.github.bewketut.wifiConnect.ConnectionSuccessListener;
import java.io.File;
import java.nio.file.DirectoryStream;
//import java.nio.*;
import java.io.IOException;
//import java.io.Stream;
import java.nio.file.Files; 
import java.nio.file.Path;
import java.nio.file.Paths; 
//import java.nio.file.Stream; 
import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.List;

//import java.util.*;


public final class FileManager extends Activity {
private static final String TAG = FileManager.class.getSimpleName();
private Context context;
private ListView list=null;
public final static int MUSIC_LIST=0, VID_LIST=1,APPS_LIST=2, DOC_LIST=3,IMAGE_LIST=4, TXT_LIST=5, OTHERFILES_LIST=6,
RECEIVED_LIST=7,WIFISCAN_LIST=8;
public static int CURRENT_LIST=MUSIC_LIST;
private final String[] filetypext= {
	"glob:**.{mp3,MP3,OGG,m4a,wav,ogg,wma,spx,oga,flac,asf,aac,aiff}*", "glob:**.{mp4,MP4,3GP,3gp,avi,ogv,mkv,webm,ogx,MPEG,WEBM,mpeg,mpeg4,mpg,mpg2,mov,mgv,med,h264,h265,flv,evo,divx,dvx}*","glob:**.{apk}","glob:**.{doc,docx,xls,pdf,rtf,ppt}*", "glob:**.{jpeg,jpg,JPG,JPEG,PNG,tiff,tif,png,gif}*","glob:**.{txt,c,java,cc,h,html,htm,xml,yml,bash,dat,md,pl,py,sh,log}", "glob:**"};


private final PathListAdapter[] adapter =(PathListAdapter[]) new PathListAdapter[8];
{};
private WifiListAdapter wifiListAdapter ;
private WifiConnector wifiConnector;
//private TextView tview;
private Button rfrshbtn;
private final boolean[] dirloaded = new boolean[8]; {
for(boolean i: dirloaded)
i=false;
}
private String message = new String();
private final static	Path sdcard0= Paths.get("/sdcard/Download"), sdcard1=Paths.get("/sdcard/Documents"),sdcard2=Paths.get("/sdcard/Pictures"),sdcard3=Paths.get("/sdcard/Music"),sdcard4= Paths.get("/sdcard/DCIM"), sdcard5= Paths.get("/sdcard/media"), sdcard6= Paths.get("/sdcard/bluetooth"),sdcard7= Paths.get("/sdcard/Xender"),
extsdcard= Paths.get("/storage/"), appsdir0=Paths.get("/system/app/"),appsdir1=Paths.get("/vendor/operator/app/"),homedir=Paths.get("/sdcard/m4power6/"),
appsdir2=Paths.get("/system/priv-app/");

private  List<PathItem> tobesendlist= new ArrayList<PathItem>();
private Drawable drawable;
private MulticastSender mks;
private static boolean filePermissionGranted=false,listed=true;
//private MulticastManager mg= new MulticastManager();
private boolean sending=false;
@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mylist);
 list = (ListView)findViewById(R.id.list);
   


final Button   txtListbtn = (Button) findViewById(R.id.txtFileListbtn),
      sendbtn = (Button) findViewById(R.id.sndbtn),
    rcvbtn = (Button) findViewById(R.id.rcvbtn),
mscbtn = (Button) findViewById(R.id.mscbtn),
vidbtn = (Button) findViewById(R.id.vidbtn),
othersbtn = (Button) findViewById(R.id.othersbtn),
docbtn = (Button) findViewById(R.id.docbtn),
imagebtn = (Button) findViewById(R.id.imagebtn),
appsbtn = (Button) findViewById(R.id.appsbtn),
connbtn = (Button) findViewById(R.id.connbtn),
hostbtn = (Button) findViewById(R.id.hostbtn),
rcvedbtn = (Button) findViewById(R.id.rcvedListbtn);
{ for(int i=0; i < 8; i++)
 adapter[i]= new PathListAdapter(this,i);
 /*new ArrayAdapter<Path>(getApplicationContext(), android.R.layout.,
            fileNameList[i]);
  adapter[7]   =       new ArrayAdapter<Path>(this,
            android.R.layout.simple_list_item_1,
            listItems);*/
}
//wifilistadapter= new WifiListAdapter(this);
    drawable=getResources().getDrawable(R.drawable.icon,getTheme());
 list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE); 
  list.setItemsCanFocus(false); 
  list.setFocusableInTouchMode(false);        
// drawable = ContextCompat.getDrawable(getApplicationContext().getTheme(),R.drawable.icon);
//ArrayList<Path> updatedList=new ArrayList<Path>();getResources().getDrawable()
				
 
// tview= (TextView)findViewById(R.id.mylist);
listFiles(appsdir0,APPS_LIST);
listFiles(appsdir1,APPS_LIST);
listFiles(appsdir2,APPS_LIST);
listAllSourceFiles(sdcard0);
listAllSourceFiles(sdcard1);
listAllSourceFiles(sdcard2);
listAllSourceFiles(sdcard3);
listAllSourceFiles(sdcard4);
listAllSourceFiles(sdcard5);
listAllSourceFiles(sdcard6);
listAllSourceFiles(sdcard7);
listAllSourceFiles(extsdcard);


dirloaded[APPS_LIST]=true;
listAllSourceFiles(homedir);




context=	getApplicationContext();

 setLocationPermission();   
wifiConnector= new WifiConnector(context);          
 wifiListAdapter = new WifiListAdapter(context,wifiConnector, new WifiListAdapter.WifiItemListener() {
            @Override
            public void onWifiItemClicked(ScanResult scanres) {
              openConnectDialog(scanres);
  }
  @Override
            public void onWifiItemLongClick(ScanResult scanResult) {
                disconnectFromAccessPoint(scanResult);
            }
        });
        
        
connbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
       

   list.setAdapter(wifiListAdapter); wifiConnector.enableWifi(FileManager.this::checkResult);
                 FileManager.this.onWifiEnabled();

  }
        });
      
hostbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
        if(mks==null){   
     Intent tetherSettings = new Intent(); tetherSettings.setClassName("com.android.settings", "com.android.settings.TetherSettings"); startActivity(tetherSettings);
 } else {
// mks.receiverThread.stop();

mks.stopReceiver();
  //hostbtn.setText("Stopped Receiving");
 hostbtn.setText("Start mgroup");
 }
   }     });

sendbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
setFileAccessPermission();
         if(mks==null && MulticastSender.isValidIp(false)){
       mks= new MulticastSender(drawable,new MulticastSender.PathItemListener() {
            @Override
            public void onpitemchanged(PathItem it) {
              list.setAdapter(adapter[RECEIVED_LIST]);
adapter[RECEIVED_LIST].addInfo(it);
  }
}
);
       
       }
     
    if(mks!=null  ){
list.setAdapter(adapter[RECEIVED_LIST]);
  mks.stopReceiver();
hostbtn.setText("Stop sender");
if(mks.isSwitch()){
mks.receiveAddr();
while(mks.peern==null && mks.run) try{ Thread.sleep(10);}
catch(InterruptedException e){ }
}
//hostbtn.setText(mks.getAddr());

 tobesendlist=selectedFiles(v); 
   int i=1;
  if(tobesendlist.size()>0){
list.setAdapter(adapter[RECEIVED_LIST]);
 message+="The following files will be sent:\n";
//mks.sendFile(pitem.getFilePath(),v);
// sending=true;
   //hostbtn.setText("Stop Sending");
 if(mks.isSwitch()) try{ Thread.sleep(3000);}
catch(InterruptedException e){ }
 for(PathItem pitem :tobesendlist){
 
    message+= i +". "+ pitem.getFileName()+"\n";i++;
mks.setRcvFlag((byte)1);

  mks.sendFile(pitem.getFilePath());
//mks.setRcvFlag((byte)0);
//mks.sendFile(pitem.getFilePath());
    }
   
// hostbtn.setText("Start mgroup");
   Toast.makeText(FileManager.this, message, Toast.LENGTH_LONG).show(); 
 message=""; 
 
   }else  Toast.makeText(FileManager.this,"Select files to send first by checking the checkboxes on the right side.", Toast.LENGTH_LONG).show();

}
else
 Toast.makeText(FileManager.this,"Please connect first with wifi!!", Toast.LENGTH_LONG).show();
       } });        
 rcvbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

 setFileAccessPermission();
if(mks==null && MulticastSender.isValidIp(false)){
        mks= new MulticastSender(drawable,new MulticastSender.PathItemListener() {
            @Override
            public void onpitemchanged(PathItem it) {
     list.setAdapter(adapter[RECEIVED_LIST]);      
adapter[RECEIVED_LIST].addInfo(it);
  }
}
);
     }  
    if(mks!=null){
list.setAdapter(adapter[RECEIVED_LIST]);
 hostbtn.setText("Stop Receiving");

mks.stopReceiver();
try{ Thread.sleep(500);}
catch(InterruptedException e){ }
	mks.receiveFile();
  }
  else Toast.makeText(FileManager.this,"Please connect first with wifi!!", Toast.LENGTH_LONG).show();

         }});
txtListbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

    setFileAccessPermission();
 CURRENT_LIST=TXT_LIST;        
listFiles(sdcard0,TXT_LIST);
listFiles(sdcard1,TXT_LIST);              
listFiles(extsdcard,TXT_LIST);
//CURRENT_LIST=TXT_LIST;
dirloaded[TXT_LIST]= true;
            }
        });

mscbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
setFileAccessPermission(); 
 CURRENT_LIST=MUSIC_LIST;    
listFiles(sdcard0,MUSIC_LIST);
listFiles(sdcard1,MUSIC_LIST);
listFiles(sdcard3,MUSIC_LIST);
listFiles(sdcard4,MUSIC_LIST);
listFiles(sdcard5,MUSIC_LIST);
listFiles(sdcard6,MUSIC_LIST);
listFiles(extsdcard,MUSIC_LIST);
dirloaded[MUSIC_LIST]= true;
            }
        });
vidbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
   setFileAccessPermission();
CURRENT_LIST=VID_LIST;          
listFiles(sdcard0,VID_LIST);
listFiles(sdcard1,VID_LIST);
listFiles(sdcard3,VID_LIST);
listFiles(sdcard4,VID_LIST);
listFiles(sdcard5,VID_LIST);
listFiles(sdcard6,VID_LIST);
listFiles(extsdcard,VID_LIST);
dirloaded[VID_LIST]= true;
            }
        });
docbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
 setFileAccessPermission();
  CURRENT_LIST=DOC_LIST;          
listFiles(sdcard0,DOC_LIST);
listFiles(sdcard1,DOC_LIST);

listFiles(extsdcard,DOC_LIST);
dirloaded[DOC_LIST]= true;
            }
        });
othersbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
  setFileAccessPermission(); 
 CURRENT_LIST=OTHERFILES_LIST;         
listFiles(sdcard0,OTHERFILES_LIST);
listFiles(sdcard1,OTHERFILES_LIST);
listFiles(sdcard5,OTHERFILES_LIST);
listFiles(sdcard6,OTHERFILES_LIST);
listFiles(extsdcard,OTHERFILES_LIST);    
dirloaded[OTHERFILES_LIST]= true;  
             }
        });
        
imagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
      setFileAccessPermission();
  CURRENT_LIST=IMAGE_LIST;     
listFiles(sdcard0,IMAGE_LIST);
listFiles(sdcard1,IMAGE_LIST);
listFiles(sdcard2,IMAGE_LIST);
listFiles(sdcard4,IMAGE_LIST);
listFiles(sdcard5,IMAGE_LIST);
listFiles(sdcard6,IMAGE_LIST);
listFiles(extsdcard,IMAGE_LIST);
dirloaded[IMAGE_LIST]= true;
            }
        });
appsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
setFileAccessPermission();
CURRENT_LIST=APPS_LIST;
 listFiles(sdcard0,APPS_LIST); 
   listFiles(sdcard1,APPS_LIST);            listFiles(extsdcard,APPS_LIST);
listFiles(appsdir0,APPS_LIST);
listFiles(appsdir1,APPS_LIST);
listFiles(appsdir2,APPS_LIST);
dirloaded[APPS_LIST]= true;

            }
        });
rcvedbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            { list.setAdapter(adapter[RECEIVED_LIST]);
}});
Intent intent = getIntent();
        
        if(intent.getAction().equals(Intent.ACTION_GET_CONTENT)) 
        	
        	adapter[CURRENT_LIST].setReturnIntent(true);
               

}
@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		
		
	}
	
private void checkResult(@NonNull final boolean isSuccess)
  {
       if (isSuccess)
           Toast.makeText(FileManager.this, "WIFI ENABLED", Toast.LENGTH_SHORT).show();
       else
           Toast.makeText(FileManager.this, "COULDN'T ENABLE WIFI", Toast.LENGTH_SHORT).show();
  }
private void onWifiEnabled(){
         //mWifiActiveTxtView.setText("Disable Wifi");
 
        if (checkLocationTurnOn()) {
        
            scanForWifiNetworks();
        }
 else {
            permissionLocationOn();
        }
      //adapter.setScanResultList(wifilist); 
    }

    private void onWifiDisabled(){
        //mWifiActiveTxtView.setText("Enable Wifi");
        //adapter.removeAll(wifilist);
    }

    
    public void scanForWifiNetworks() {
    Toast.makeText(FileManager.this, "Starting wifi scan" , Toast.LENGTH_SHORT).show();  wifiConnector.scanWifi(this::getScanResults).start();
    Toast.makeText(FileManager.this, "Ending wifi scan" , Toast.LENGTH_SHORT).show();    
 }

private void getScanResults(@NonNull final List<ScanResult> results)
    {
    if (results.isEmpty())
    {
                       Toast.makeText(FileManager.this, "Error on getting wifi list, error code:" , Toast.LENGTH_SHORT).show();
 //Log.d( "SCAN RESULTS IT'S EMPTY");
        return;
    }
   // Log.d( "GOT SCAN RESULTS " + results);
//   Toast.makeText(FileManager.this, "Starting wifi scan result: "+ results.get(0).SSID , Toast.LENGTH_LONG).show();
   wifiListAdapter.clearList(); 
    for(ScanResult res: results)
    wifiListAdapter.addItem(new WifiItem(res,drawable,false));
     
}
    public void openConnectDialog(ScanResult  scanResult){
        ConnectToWifiDialog dialog = new ConnectToWifiDialog(FileManager.this, scanResult);
       dialog.setConnectButtonListener(new ConnectToWifiDialog.DialogListener() {
            @Override
            public void onConnectClicked(ScanResult scanResult, String password) {
                connectToWifiAccessPoint(scanResult, password);
            }
        });
       dialog.show();
    }

    
    public void connectToWifiAccessPoint(final ScanResult scanResult, String password) {
   
  wifiConnector.connectWith(scanResult.SSID, scanResult.BSSID,password)
          .setTimeout(20000)
          .onConnectionResult(new ConnectionSuccessListener() {
              @Override
              public void success() {
                  Toast.makeText(FileManager.this, "SUCCESS!", Toast.LENGTH_SHORT).show();
              }

              @Override
              public void failed(@NonNull ConnectionErrorCode errorCode) {
                  Toast.makeText(FileManager.this, "EPIC FAIL!" + errorCode.toString(), Toast.LENGTH_SHORT).show();
              }
          
          })
          .start();         
       
    }

    
    public void disconnectFromAccessPoint(ScanResult scanResult) {
        wifiConnector.disconnect(new DisconnectionSuccessListener() {
                    @Override
                    public void success() {
                        Toast.makeText(FileManager.this, "Disconnect success!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void failed(@NonNull DisconnectionErrorCode errorCode) {
                        Toast.makeText(FileManager.this, "Failed to disconnect: " + errorCode.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
private Boolean permissionLocationOn() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void setLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1001);
        }
    }

    private Boolean checkLocationTurnOn() {
        boolean onLocation = true;
        boolean permissionGranted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && permissionGranted) {
            LocationManager lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
            boolean gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (!gps_enabled) {
                onLocation = false;
                AlertDialog.Builder dialog = new AlertDialog.Builder(new ContextThemeWrapper(this, getTheme()));
               
                dialog.setMessage("Please turn on your location");
                dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                });
                dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                    }
                });
                dialog.show();
            }
        }
        return onLocation;
    }
    // endregion
private void setFileAccessPermission() {

if(!filePermissionGranted){

if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
filePermissionGranted =(Environment.isExternalStorageManager()||Environment.isExternalStorageLegacy());}
else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){
filePermissionGranted=Environment.isExternalStorageLegacy();}
 else  filePermissionGranted=checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

if(!filePermissionGranted){
listed=false;
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
filePermissionGranted=checkFileAccessTurnOn();
else        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1001);
        }

    }

}
if(filePermissionGranted && !listed){
listAllSourceFiles(sdcard0);
listAllSourceFiles(sdcard1);
listAllSourceFiles(sdcard2);
listAllSourceFiles(sdcard3);
listAllSourceFiles(sdcard4);
listAllSourceFiles(sdcard5);
listAllSourceFiles(sdcard6);
listAllSourceFiles(sdcard7);
listAllSourceFiles(extsdcard);
listed=true;
}
}
private Boolean checkFileAccessTurnOn() {
        boolean onFileAccess = true;
  
           AlertDialog.Builder dialog = new AlertDialog.Builder(new ContextThemeWrapper(this, getTheme()));
               
                dialog.setMessage("Please give access to phone memory by switching the option to on next.");
                dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
 if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
 {
try { Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION); intent.addCategory("android.intent.category.DEFAULT"); intent.setData(Uri.parse(String.format("package:%s",getApplicationContext().getPackageName()))); startActivityForResult(intent, 2296); }
 catch (Exception e) { Intent intent = new Intent(); intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION); startActivityForResult(intent, 2296); }
 }
/*else{Intent intent = new
 //Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS); 
//startActivityForResult(intent, 0); 
}*/
         }    
                });
                dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                    }
                });
                dialog.show();
            
       

        return onFileAccess;
    }
    // endregion
   
public void listFiles(Path dir, int ftype){
list.setAdapter(adapter[ftype]);
if(!dirloaded[ftype]){
try(DirectoryStream<Path> ad =listSourceFiles(dir,adapter[ftype], ftype)){}
catch(IOException ex){}		
}
}
public int ftype(Path path)
{
	if(!Files.isDirectory(path)){
for(int i=0; i<6;i++)
	if(FileSystems.getDefault().getPathMatcher(filetypext[i]).matches(path)) return i;
    return OTHERFILES_LIST;
}
//if(FileSystems.getDefault().getPathMatcher("glob:**").matches(path))
	
return -1;	
	}
//removeSelectedItems(list,listItems);
/*
static class ViewHolder { protected TextView text; protected CheckBox checkbox; }
*/
@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
LayoutInflater linflater = getLayoutInflater();
		if (id == R.id.action_settings) {
			
			/*int a = 2/0;
			System.out.println(a);*/
			
			return true;
		}
 else if (id== R.id.about){
AlertDialog.Builder aboutDialog = new AlertDialog.Builder(new ContextThemeWrapper(this, getTheme()));
aboutDialog.setTitle("About...");
			aboutDialog.setIcon(R.drawable.ic_eth_about);
			aboutDialog.setView(linflater.inflate(R.layout.about_popup, null,
					false));
			aboutDialog.setPositiveButton("Ok", null);
			aboutDialog.show();
}
		return super.onOptionsItemSelected(item);
	}
public List<PathItem> selectedFiles(View v){
   PathItem pathitem=null;
   tobesendlist.clear();
 for(int i=0; i <7; i++){
 
List<Integer> cItemsPos = adapter[i].getCheckedList();
//PathListAdapter temp=null;
boolean cflag=false;
//holder = (ViewHolder) v.getTag(); 
for(int j=0; j < cItemsPos.size(); j++){
int pos=cItemsPos.get(j);

if(adapter[i].getItem(pos).isChecked()){
tobesendlist.add(adapter[i].getItem(pos));
adapter[i].getItem(pos).setChecked(false);
 cflag=true;
}
}
if(cflag){
//temp= new PathListAdapter(this);
adapter[i].setPathList(adapter[i].getPathList());
//adapter[i]=temp;
 cflag=false;
}
}
//list.setAdapter(adapter[CURRENT_LIST]);
return tobesendlist;
}



  /* 

public ArrayList <Path> removeSelectedItems(ListView lv, ArrayList<Path> list){

ArrayList <Path> updatedList = new ArrayList<Path>(); //initialize the second ArrayList

int count = lv.getCount();  //number of my ListView items
SparseBooleanArray checkedItemPositions = lv.getCheckedItemPositions();
for (int i=0;i < count;i++){
    if(!checkedItemPositions.get(i))

    updatedList.add((Path)list.get(i)); //liveNames is the current ArrayList     
    //Log.e("TEST", liveNames.get(i));
}
ArrayAdapter<Path> adapter = new ArrayAdapter<Path>(this,
        android.R.layout.simple_list_item_multiple_choice, updatedList);

lv.setAdapter(adapter);
return updatedList;
}

    public static String showFile(File file) {
        if (file.isDirectory()) {
            return ("Directory: " + file.getAbsolutePath()+"\n");
        } else {
            return ("File: " + file.getAbsolutePath()+"\n");
        }
    }
 */

public void listAllSourceFiles(Path dir) 
     {
     	 try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*")) { for (Path entry: stream) { 
int pathtype=ftype(entry);
if(pathtype!=-1){
//	int adapid=entry.ftype();
   
	 adapter[pathtype].addItem(
	new PathItem(entry.getFileName().toString(),entry,null,Files.size(entry),drawable,(pathtype!=APPS_LIST),false)); 
}
else listAllSourceFiles(entry);
//l.add(entry);
} } catch (IOException  ex) { 
}
for(int i=0; i <7; i++)if(i!=2)dirloaded[i]=true;
     }

public DirectoryStream <Path> listSourceFiles(Path dir, PathListAdapter result, int listadapid) throws IOException { 
CURRENT_LIST=listadapid;
DirectoryStream.Filter<Path> filter = new DirectoryStream.Filter<Path>() {
         public boolean accept(Path file) throws IOException {
             return
   FileSystems.getDefault().getPathMatcher(filetypext[CURRENT_LIST]).matches(file) || Files.isDirectory(file);
         }
     };
 

DirectoryStream <Path> res=null;;
//List<Path> l= (List<Path>)findViewById(id);
 try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, filter)) { res=stream; for (Path entry: stream) { 
if(Files.isDirectory(entry))
listSourceFiles(entry,result,listadapid);
else 
//	int adapid=entry.ftype();
	 	 result.addItem(new PathItem(entry.getFileName().toString(),entry,null,Files.size(entry),drawable,true,false)); 
//adapter{}; 

//l.add(entry);
} } catch (IOException  ex) { // I/O error encounted during the iteration, the cause is an IOException
 //throw ex.getCause(); 
 res= null;
}

 return res; }


}

/****
********
filter.Filter("*.{c,h}") ;  
 Stream ds=Files.walk(dir).filter(filter);
try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*")) { 
for (Path entry: stream) {
	
adapter.add(entry);
if(Files.isDirectory(entry))
listSourceFiles(entry,adapter);
//	lv.setText(entry.getFileName().toString()+"\n");

} }
 catch (IOException  ex) {
//	 throw ex.getCause(); 
}

//List<Path> l=(List<Path>)
 //  String files = new String("hello world!");  
   


//lv.setText(files);

}

list.setOnItemClickListener(new AdapterView.OnItemClickListener() { @Override public void onItemClick(AdapterView<?> parent, View item, int position, long id) { Path path = listAdapter.getItem(position); path.toggleChecked(); 
ViewHolder viewHolder = (ViewHolder) item .getTag(); viewHolder.getCheckBox().setChecked(path.isChecked()); } });

adapter = new ArrayAdapter<String>(this,
        android.R.layout.simple_list_item_multiple_choice, updatedList);

setListAdapter(adapter);}

   private static class DirectoriesFilter implements Filter<Path> {
    @Override
    public boolean accept(Path entry) throws IOException {
        return super.accept(entry)  || Files.isDirectory(entry);
    }
}*/


































































































































