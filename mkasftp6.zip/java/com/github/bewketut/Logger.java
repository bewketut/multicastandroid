package com.github.bewketut;

public interface Logger {
    void log(int priority, String tag, String message);
}
