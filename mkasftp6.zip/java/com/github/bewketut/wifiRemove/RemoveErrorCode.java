package com.github.bewketut.wifiRemove;

public enum RemoveErrorCode {
    COULD_NOT_GET_WIFI_MANAGER,
    COULD_NOT_GET_CONNECTIVITY_MANAGER,
    COULD_NOT_REMOVE,
}
