package com.github.bewketut.utils;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.RequiresApi;

public class VersionUtil{
private VersionUtil(){}
    @SuppressLint("AnnotateVersionCheck")
    public static boolean is29AndAbove() {return  Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q;
    }


    @RequiresApi(Build.VERSION_CODES.Q)
   public static Intent getPanelIntent()  {
return new Intent(Settings.Panel.ACTION_WIFI);
}
}