/**********************************
*****last date:Fri 23 Sep,24 June,21 June,7 May,March 2022, February 2021
**** copyright owner(author):
 Bewketu Tadilo Shibabaw
**** license: BSD (put copyright ***holder name (i.e. Bewketu Tadilo Shibabaw and signature ~bts) on  this original code or derivative  and binaries to show the copyright embedded in it on further)  ********************************************************/
package com.github.bewketut;
import android.graphics.drawable.Drawable;
import java.nio.file.Path;
/**
 * Each Row Item in our List is store here and used in our adapter
 */
public class PathItem implements Comparable<PathItem> {
  private Path path;
	private String fileName = "";
	private String fileSize;
	private long fileSiz=0;
	private boolean mChecked;
	private Drawable mImage;
  private boolean sortable=true;

	public PathItem( String text, Path p, String sizestr,long size,Drawable imageView,boolean ss, boolean checked) {
		setChecked(checked); 
    setFilePath(p);
		setFileName(text);
   sortable=ss;
		fileSiz=size;
if(sizestr!=null) fileSize=sizestr;
else
		setFileSize( size);
		setmImage(imageView);
	}
 public void setFilePath(Path p){
         path = p;
}
public boolean isSortable(){
return sortable;
}
public Path getFilePath(){
return path;
}
	public void setChecked(boolean value) {
		this.mChecked = value;
	}

	public boolean isChecked() {
		return this.mChecked;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String text) {
		fileName= text;
	}
	 String formatSize(long size){
if(size < 1024)
return ""+ size;
else if (size < 1024*1024)
return "" + formatfloat2((size*1.0f)/1024) + "KB";
else if (size < (1024*1024*1024))
return "" + formatfloat2((size*1.0f)/(1024*1024)) + "MB";
else return "" + formatfloat2((size*1.0f)/(1024*1024*1024)) + "GB";
}
private static String formatfloat2(float num){
return ""+(sizeceil(100*((sizeceil(num*1000)*1.0f)/1000))*1.0f)/100;
}
public void setFileSize1(long siz) {
		 fileSiz= siz;
	}
	public void setFileSize(long siz) {
		 fileSize= formatSize(siz);
	}
	public long getFileSize1() {
		 return fileSiz;
	}
	private static long sizeceil(float num){
long temp1=(long)num;

if(num%temp1 > 0.5f) return temp1+1;
else return temp1;
}
	public String getFileSize() {
		 return fileSize;
	}
	public Drawable getmImage() {
		return mImage;
	}

	public void setmImage(Drawable mImage) {
		this.mImage = mImage;
	}

	/** Make PathItem comparable by its name */
	public int compareTo(PathItem other) {
		if (this.fileSiz != 0)
			return Long.compare(this.fileSiz,other.getFileSize1());
		else
			throw new IllegalArgumentException();
	}
}
