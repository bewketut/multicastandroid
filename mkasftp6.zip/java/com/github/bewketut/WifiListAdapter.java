package com.github.bewketut;
import android.widget.BaseAdapter;
//import android.graphics.drawable.Drawable;
import android.annotation.SuppressLint;
import android.graphics.Color;

import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;

import java.util.ArrayList;
import java.util.List;
//import java.nio.file.Path;
import android.content.Context;
//import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.github.bewketut.WifiConnector;
import android.util.Log;
//import com.github.bewketut.WifiConnector;
final public class WifiListAdapter extends BaseAdapter  implements OnCheckedChangeListener, OnClickListener  {
	private static final String TAG = WifiListAdapter.class.getSimpleName();

	private Context context;
	private LayoutInflater mInflater = null;
	 	// Our List of Items from Path.java
//super().super();
	private List<WifiItem> mItems = new ArrayList<WifiItem>();

    private WifiConnector wifiConnector=null;
    private WifiItemListener wifiItemListener;

     
	
	public WifiListAdapter(Context context, WifiConnector wc,WifiItemListener wifiItemListener) {
        this.wifiItemListener = wifiItemListener;
        wifiConnector= wc;
		Log.d(TAG, "Constructor");
		this.context = context;
		mInflater = LayoutInflater.from(context);
	}
public void setScanList(List<WifiItem> scanResultList) {
        mItems = scanResultList;
        notifyDataSetChanged();
    }
	public void addItem(WifiItem it) {
		mItems.add(it);				
		notifyDataSetChanged();							// Adding Items to the list
	}
//public void removeAll(List<WifiItem> lis){
 // lis.removeAll(lis);
//}
	public List<WifiItem> getScanList( ) {				// Adding Items by passing a whole new List
		return mItems;
	}
	public void clearList(){
	mItems.clear();
	notifyDataSetChanged();
	}

	public int getCount() {
		return mItems.size();
	}
/*public void setItemAt(List<WifiItem> lis,
WifiItem it,int pos){
//if(lis.get(pos)!=null)
 lis.get(pos).setwifiItem(it);
//else lis.add(it);
 }
 */
	public WifiItem getItem(int position) {
		return mItems.get(position);
	}

	public long getItemId(int position) {
		return position;
	}
	
	/*
	 * This gets called every time ListView needs a new Row Item
	 * position holds the position on the row in the ListView
	 * convertView is the new view we have to filled with our custom --> list_item.xml
	 */
	public  View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vHolder = null;

		if (convertView != null)
			vHolder = (ViewHolder) convertView.getTag();								// convertView is been recycled
		else {
			convertView = (View) mInflater.inflate(R.layout.item1, null);			// Set content of new View with list_item.xml

			vHolder = new ViewHolder();
			vHolder.checkBox = ((CheckBox) convertView.findViewById(R.id.cbBox));	// Getting pointers
			vHolder.wifiName = ((TextView) convertView.findViewById(R.id.apItem_name));
				vHolder.wifiIntensity = ((TextView) convertView.findViewById(R.id.apItem_intensity));
			vHolder.imageView = ((ImageView) convertView.findViewById(R.id.ivImage));

			vHolder.checkBox.setOnCheckedChangeListener(this);							// Setting Listeners
			vHolder.imageView.setOnClickListener(this);
//vHolder.wifiName.setOnClickListener(this);
		//vHolder.wifiName.setOnLongClickListener(this);
			convertView.setTag(vHolder);
		}

		vHolder.checkBox.setId(position);												// This is part of the Adapter APi
		vHolder.wifiName.setId(position);
			vHolder.wifiIntensity.setId(position);													// Do not delete !!!
		vHolder.imageView.setId(position);

		
		if (mItems.get(position).isChecked()) {										// Setting parameters for the View from our mItems list
			vHolder.checkBox.setChecked(true);
		} else {
			vHolder.checkBox.setChecked(false);
		}

		vHolder.wifiName.setText(mItems.get(position).scanresult.SSID);
		vHolder.wifiIntensity.setText(WifiManager.calculateSignalLevel(mItems.get(position).scanresult.level, 100) + "%");
/*vHolder.textView2.setText("Security Type: "+ WifiConnector.getWifiSecurityType((ScanResult)mItems.get(position)));*/
		vHolder.imageView.setImageDrawable(mItems.get(position).getmImage());
		
		return convertView;
	}
	
	public static class ViewHolder {
		CheckBox checkBox;
		TextView wifiName;
        TextView wifiIntensity;
		ImageView imageView;
		
        @SuppressLint("SetTextI18n")
        public void fill(WifiItem scanResult, String currentSsid) {
            if (scanResult.scanresult.SSID.equals(currentSsid)) {
                wifiName.setTextColor(Color.GREEN);
            }
            wifiName.setText(scanResult.scanresult.SSID);
            wifiIntensity.setText(WifiManager.calculateSignalLevel(scanResult.scanresult.level, 100) + "%");
        }
	}





	/*
	 *
	@SuppressLint("SetTextI18n")
        public void fill(WifiItem scanResult, String currentSsid) {
            if (scanResult.scanresult.SSID.equals(currentSsid)) {
                wifiName.setTextColor(Color.GREEN);
            }
            wifiName.setText(scanResult.scanresult.SSID);
            wifiIntensity.setText(WifiManager.calculateSignalLevel(scanResult.scanresult.level, 100) + "%");
        } Ok for this test but Toast are going to show every time the row comes into View
	 */
	public  void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		Log.d(TAG, "Checked");
		int position=buttonView.getId();
String BSSID=new String();
ScanResult scanres;
		if (isChecked) {
			
			BSSID=mItems.get(position).scanresult.BSSID;
		   if (wifiConnector.isConnectedToBSSID(BSSID)){
			Toast.makeText(context, BSSID +" Already connected!", Toast.LENGTH_SHORT).show();
			}
		else {
  scanres=mItems.get(position).scanresult;                  wifiItemListener.onWifiItemClicked(scanres);
                  }
       //wifiItemListener.onWifiItemClicked(mItems.get(position));
       
        mItems.get(position).setChecked(true);           }
                    else
			mItems.get(buttonView.getId()).setChecked(false);
		
	}

	@Override
	public void onClick(View v) {
		Toast.makeText(context, "ImageClicked", Toast.LENGTH_LONG).show();
	}
	/*@Override
	public void onLongClick(View v) {
		Toast.makeText(context, "ImageClicked", Toast.LENGTH_LONG).show();
	}*/
	interface WifiItemListener {
        void onWifiItemClicked(ScanResult scanResult);

        void onWifiItemLongClick(ScanResult scanResult);
    }


}
