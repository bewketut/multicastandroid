package com.github.bewketut.wifiState;

public interface WifiStateCallback {
    void onWifiEnabled();
}
