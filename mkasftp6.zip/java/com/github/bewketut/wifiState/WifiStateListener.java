package com.github.bewketut.wifiState;

public interface WifiStateListener {
    void isSuccess(boolean isSuccess);
}
