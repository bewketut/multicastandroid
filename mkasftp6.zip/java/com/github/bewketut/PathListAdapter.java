/**********************************
*****last date:Fri 23 Sep,24 June,21 June,7 May,March 2022, February 2021
**** copyright owner(author):
 Bewketu Tadilo Shibabaw
**** license: BSD (put copyright ***holder name (i.e. Bewketu Tadilo Shibabaw and signature ~bts) on  this original code or derivative  and binaries to show the copyright embedded in it on further)  ********************************************************/
package com.github.bewketut;
import android.widget.BaseAdapter;
import android.graphics.drawable.Drawable;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
//import java.nio.file.Path;

import java.util.Comparator;

public class PathListAdapter extends BaseAdapter  implements OnCheckedChangeListener, OnClickListener  {
	private static final String TAG = PathListAdapter.class.getSimpleName();

	private Context context;
	private LayoutInflater mInflater = null;
	private List<PathItem> mItems = new ArrayList<PathItem>(); 	// Our List of Items from Path.java
//super().super();
	private List<Integer> cItems = new ArrayList<Integer>();
	private int kbIndex=0;
	private int mbIndex=0;
	private int tenmbIndex=0;
	private int twentymbIndex=0;
	private int fiftymbIndex=0;
	private int hundredmbIndex=0;
	private static final int KB=1024;
	private static final int MB=KB*KB;
	private static final int TENMB=10*MB;
	private static final int TWENTYMB=20*MB;
	private static final int FIFTYMB=50*MB;
	private static final int  HUNDREDMB=100*MB;
	public PathListAdapter(Context context) {
		Log.d(TAG, "Constructor");
		this.context = context;
		mInflater = LayoutInflater.from(context);
	}
public void addInfo(PathItem it){
mItems.add(0,it);
notifyDataSetChanged();
}
	public void addItem(PathItem it) {
  int sz=mItems.size();
  long fileSize=it.getFileSize1();
  if(sz==0) mItems.add(it);
  	else if(fileSize>HUNDREDMB){
  	if(fileSize> mItems.get(hundredmbIndex).getFileSize1()) ;
  	else hundredmbIndex++;
	mItems.add(hundredmbIndex,it);
	fiftymbIndex++;
	twentymbIndex++;
	tenmbIndex++;
	mbIndex++;
	kbIndex++;
	}
else if(fileSize>FIFTYMB){
  	if(fileSize> mItems.get(fiftymbIndex).getFileSize1()) ;
  	else fiftymbIndex++;
	mItems.add(fiftymbIndex,it);
	fiftymbIndex++;
	twentymbIndex++;
	tenmbIndex++;
	mbIndex++;
	kbIndex++;
	}
	 else if(fileSize>TWENTYMB){
  	if(fileSize> mItems.get(twentymbIndex).getFileSize1()) ;
  	else twentymbIndex++;
	mItems.add(twentymbIndex,it);
    tenmbIndex++;
	mbIndex++;
	kbIndex++;
	
	}
	else if(fileSize>TENMB){
  	if(fileSize> mItems.get(tenmbIndex).getFileSize1()) ;
  	else tenmbIndex++;
	mItems.add(tenmbIndex,it);
    
	mbIndex++;
	kbIndex++;
	
	}
	else if(fileSize>MB){
  	if(fileSize> mItems.get(mbIndex).getFileSize1()) ;
  	else mbIndex++;
	mItems.add(mbIndex,it);
	kbIndex++;
	}
	else if(fileSize>KB){
  	if(fileSize> mItems.get(kbIndex).getFileSize1()) ;
  	else kbIndex++;
	mItems.add(kbIndex,it);

	}
	else 
	mItems.add(it);
	//leastfsIndex=sz-1;
	notifyDataSetChanged();
			}

	public void setPathList(List<PathItem> lit) {				// Adding Items by passing a whole new List
		cItems.clear();
		mItems = lit;
		notifyDataSetChanged();
	}
public List<PathItem> getPathList(){
return mItems;
}
public List<Integer> getCheckedList(){
return cItems;
}
	public int getCount() {
		return mItems.size();
	}

	public PathItem getItem(int position) {
		return mItems.get(position);
	}

	public long getItemId(int position) {
		return position;
	}
	public List<PathItem> sortList(){
	mItems.sort(NatOrderCompar.INSTANCE.reversed());
	//notifyDataSetChanged();
	return mItems;
	}

/*	
	public void setChecked(int pos,boolean value) {
		getItem(pos).setChecked(value);
		notifyDataSetChanged();
	}

	public boolean isChecked(int pos) {
		return getItem(pos).isChecked();
	}
*/
	/*
	 * This gets called every time ListView needs a new Row Item
	 * position holds the position on the row in the ListView
	 * convertView is the new view we have to filled with our custom --> list_item.xml
	 */
	public  View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vHolder = null;

		if (convertView != null)
			vHolder = (ViewHolder) convertView.getTag();								// convertView is been recycled
		else {
			convertView = (View) mInflater.inflate(R.layout.item, null);			// Set content of new View with list_item.xml

			vHolder = new ViewHolder();
			vHolder.checkBox = ((CheckBox) convertView.findViewById(R.id.cbBox));	// Getting pointers
			vHolder.fileName = ((TextView) convertView.findViewById(R.id.tvFileName));
				vHolder.fileSize = ((TextView) convertView.findViewById(R.id.tvFileSize));
			vHolder.imageView = ((ImageView) convertView.findViewById(R.id.ivImage));

			vHolder.checkBox.setOnCheckedChangeListener(this);							// Setting Listeners
			vHolder.imageView.setOnClickListener(this);
			
			convertView.setTag(vHolder);
		}

		vHolder.checkBox.setId(position);												// This is part of the Adapter APi
		vHolder.fileName.setId(position);
			vHolder.fileSize.setId(position);													// Do not delete !!!
		vHolder.imageView.setId(position);

		
		if (mItems.get(position).isChecked()) {										// Setting parameters for the View from our mItems list
			vHolder.checkBox.setChecked(true);
		} else {
			vHolder.checkBox.setChecked(false);
		}

		vHolder.fileName.setText(mItems.get(position).getFileName());
		
		vHolder.fileSize.setText(mItems.get(position).getFileSize());
		vHolder.imageView.setImageDrawable(mItems.get(position).getmImage());
		
		return convertView;
	}
	
	public static class ViewHolder {
		CheckBox checkBox;
		TextView fileName;
    TextView fileSize;
		ImageView imageView;
	}

	/*
	 * Ok for this test but Toast are going to show every time the row comes into View
	 */
	public  void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		Log.d(TAG, "Checked");
		int position = buttonView.getId();

		if (isChecked) {
			mItems.get(position).setChecked(true);
			cItems.add(position);
			//mItems.get(position).setChecked(false);
		//	Toast.makeText(context, mItems.get(position).getText(), Toast.LENGTH_LONG).show();
		} else {
			mItems.get(buttonView.getId()).setChecked(false); //cItems.remove(position);
		}
	}

	@Override
	public void onClick(View v) {
		Toast.makeText(context, "ImageClicked", Toast.LENGTH_LONG).show();
	}

enum NatOrderCompar implements Comparator<PathItem> {
        INSTANCE;

        @Override
        public int compare(PathItem c1, PathItem c2) {
            return Long.compare(c1.getFileSize1(),c2.getFileSize1());
        }

        @Override
        public Comparator<PathItem> reversed() {
            return Comparator.reverseOrder();
        }
    }

}
