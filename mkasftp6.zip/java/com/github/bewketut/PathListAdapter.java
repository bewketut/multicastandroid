/**********************************
*****last date:Fri 23 Sep,24 June,21 June,7 May,March 2022, February 2021
**** copyright owner(author):
 Bewketu Tadilo Shibabaw
**** license: BSD (put copyright ***holder name (i.e. Bewketu Tadilo Shibabaw and signature ~bts) on  this original code or derivative  and binaries to show the copyright embedded in it on further)  ********************************************************/
package com.github.bewketut;

import android.app.Activity;
import android.widget.BaseAdapter;
import android.graphics.drawable.Drawable;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.content.Intent;
import android.net.Uri;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.content.ActivityNotFoundException;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.util.ArrayList;
import java.util.List;
//import java.nio.file.Path;
import java.io.File;
import java.util.Comparator;

public class PathListAdapter extends BaseAdapter  implements OnCheckedChangeListener, OnClickListener  {
	private static final String TAG = PathListAdapter.class.getSimpleName();

	private Context context;
	private LayoutInflater mInflater = null;
	private List<PathItem> mItems = new ArrayList<PathItem>(); 	// Our List of Items from Path.java
//super().super();
	private List<Integer> cItems = new ArrayList<Integer>();
	private int kbIndex=0;
	private int mbIndex=0;
	private int tenmbIndex=0;
	private int twentymbIndex=0;
	private int fiftymbIndex=0;
	private int hundredmbIndex=0;
	private static final int KB=1024;
	private static final int MB=KB*KB;
	private static final int TENMB=10*MB;
	private static final int TWENTYMB=20*MB;
	private static final int FIFTYMB=50*MB;
	private static final int  HUNDREDMB=100*MB;
private boolean mReturnIntent=false;
private int filetype=-1;
	public PathListAdapter(Context context,int ft) {
		Log.d(TAG, "Constructor");
		this.context = context;
		mInflater = LayoutInflater.from(context);
filetype=ft;
	}
public void addInfo(PathItem it){
mItems.add(0,it);
notifyDataSetChanged();
}
public void setReturnIntent(boolean td){
mReturnIntent=td;
}
	public void addItem(PathItem it) {
  int sz=mItems.size();
  long fileSize=it.getFileSize1();
  if(it.isSortable()){
  if(sz==0) mItems.add(it);
  	else if(fileSize>HUNDREDMB){
  	if(fileSize> mItems.get(hundredmbIndex).getFileSize1()) ;
  	else hundredmbIndex++;
	mItems.add(hundredmbIndex,it);
	fiftymbIndex++;
	twentymbIndex++;
	tenmbIndex++;
	mbIndex++;
	kbIndex++;
	}
else if(fileSize>FIFTYMB){
  	if(fileSize> mItems.get(fiftymbIndex).getFileSize1()) ;
  	else fiftymbIndex++;
	mItems.add(fiftymbIndex,it);
	fiftymbIndex++;
	twentymbIndex++;
	tenmbIndex++;
	mbIndex++;
	kbIndex++;
	}
	 else if(fileSize>TWENTYMB){
  	if(fileSize> mItems.get(twentymbIndex).getFileSize1()) ;
  	else twentymbIndex++;
	mItems.add(twentymbIndex,it);
    tenmbIndex++;
	mbIndex++;
	kbIndex++;
	
	}
	else if(fileSize>TENMB){
  	if(fileSize> mItems.get(tenmbIndex).getFileSize1()) ;
  	else tenmbIndex++;
	mItems.add(tenmbIndex,it);
    
	mbIndex++;
	kbIndex++;
	
	}
	else if(fileSize>MB){
  	if(fileSize> mItems.get(mbIndex).getFileSize1()) ;
  	else mbIndex++;
	mItems.add(mbIndex,it);
	kbIndex++;
	}
	else if(fileSize>KB){
  	if(fileSize> mItems.get(kbIndex).getFileSize1()) ;
  	else kbIndex++;
	mItems.add(kbIndex,it);

	}
	else 
	mItems.add(it);
} else mItems.add(0,it);
	//leastfsIndex=sz-1;
	notifyDataSetChanged();
			}

	public void setPathList(List<PathItem> lit) {				// Adding Items by passing a whole new List
		cItems.clear();
		mItems = lit;
		notifyDataSetChanged();
	}
public List<PathItem> getPathList(){
return mItems;
}
public List<Integer> getCheckedList(){
return cItems;
}
	public int getCount() {
		return mItems.size();
	}

	public PathItem getItem(int position) {
		return mItems.get(position);
	}

	public long getItemId(int position) {
		return position;
	}
	public List<PathItem> sortList(){
	mItems.sort(NatOrderCompar.INSTANCE.reversed());
	//notifyDataSetChanged();
	return mItems;
	}

/*	
	public void setChecked(int pos,boolean value) {
		getItem(pos).setChecked(value);
		notifyDataSetChanged();
	}

	public boolean isChecked(int pos) {
		return getItem(pos).isChecked();
	}
*/
	/*
	 * This gets called every time ListView needs a new Row Item
	 * position holds the position on the row in the ListView
	 * convertView is the new view we have to filled with our custom --> list_item.xml
	 */
	public  View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vHolder = null;

		if (convertView != null)
			vHolder = (ViewHolder) convertView.getTag();								// convertView is been recycled
		else {
			convertView = (View) mInflater.inflate(R.layout.item, null);			// Set content of new View with list_item.xml

			vHolder = new ViewHolder();
			vHolder.checkBox = ((CheckBox) convertView.findViewById(R.id.cbBox));	// Getting pointers
			vHolder.fileName = ((TextView) convertView.findViewById(R.id.tvFileName));
				vHolder.fileSize = ((TextView) convertView.findViewById(R.id.tvFileSize));
			vHolder.imageView = ((ImageView) convertView.findViewById(R.id.ivImage));

			vHolder.checkBox.setOnCheckedChangeListener(this);							// Setting Listeners
		vHolder.imageView.setOnClickListener(this);
				vHolder.fileName.setOnClickListener(this);
			
			convertView.setTag(vHolder);
		}

		vHolder.checkBox.setId(position);												// This is part of the Adapter APi
		vHolder.fileName.setId(position);
			vHolder.fileSize.setId(position);													// Do not delete !!!
		vHolder.imageView.setId(position);

		
		if (mItems.get(position).isChecked()) {										// Setting parameters for the View from our mItems list
			vHolder.checkBox.setChecked(true);
		} else {
			vHolder.checkBox.setChecked(false);
		}

		vHolder.fileName.setText(mItems.get(position).getFileName());
		
		vHolder.fileSize.setText(mItems.get(position).getFileSize());
		vHolder.imageView.setImageDrawable(mItems.get(position).getmImage());
		
		return convertView;
	}
	
	public static class ViewHolder {
		CheckBox checkBox;
		TextView fileName;
    TextView fileSize;
		ImageView imageView;
	}

	/*
	 * Ok for this test but Toast are going to show every time the row comes into View
	 */
	public  void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		Log.d(TAG, "Checked");
		int position = buttonView.getId();

		if (isChecked) {
			mItems.get(position).setChecked(true);
			cItems.add(position);
			//mItems.get(position).setChecked(false);
		//	Toast.makeText(context, mItems.get(position).getText(), Toast.LENGTH_LONG).show();
		} else {
			mItems.get(buttonView.getId()).setChecked(false); //cItems.remove(position);
		}
	}
	private void returnIntentResults(String data) {
		mReturnIntent = false;
		
		Intent ret = new Intent();
		ret.setData(Uri.parse(data));
	((Activity)context).setResult(-1, ret);
		
	((Activity)context).finish();
	}
	@Override
	public void onClick(View v) {
final int pos= v.getId();
final int cl=filetype;
final File filepath=getItem(pos).getFilePath().toFile();
final String filename=getItem(pos).getFileName().trim(), item_ext;
  if(filename.lastIndexOf(".") < filename.length())	
    		item_ext = filename.substring(filename.lastIndexOf("."), filename.length());
    	else item_ext = "";

Intent fileIntent = new Intent();
	fileIntent.setAction(Intent.ACTION_VIEW);  Uri uri = FileProvider.getUriForFile(context, "com.github.bewketut.fileprovider", filepath); fileIntent.putExtra(Intent.EXTRA_STREAM, uri); 
fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); 
//fileIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);   
if(mReturnIntent) 
	    			returnIntentResults(filepath.toString());


    		
else if(cl==FileManager.MUSIC_LIST){	    		
		fileIntent.setDataAndType(uri,"audio/*");
		    		context.startActivity(fileIntent);
//Toast.makeText(context, "MusicClicked", Toast.LENGTH_LONG).show();
}
else if(cl==FileManager.VID_LIST){
fileIntent.setDataAndType(uri,"video/*");
		    		
	
	    				    		context.startActivity(fileIntent);

}
else if(cl==FileManager.IMAGE_LIST){
fileIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);   
fileIntent.setDataAndType(uri,"image/*");
		    		
		    		context.startActivity(fileIntent);

}
else if(cl==FileManager.APPS_LIST){
fileIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);   
fileIntent.setDataAndType(uri,"application/vnd.android.package-archive");
    		context.startActivity(fileIntent);
	    		


}
else if(cl==FileManager.DOC_LIST){

	if(item_ext.equalsIgnoreCase(".pdf"))  fileIntent.setDataAndType(uri,"application/pdf"); 
 		 
else{
 fileIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);     fileIntent.setDataAndType(uri,"application/doc"); 
}  		   		

	 try {
			    	context.startActivity(fileIntent);
	    		
			    		} catch (ActivityNotFoundException e) {
			    			Toast.makeText(context, "Sorry, couldn't find a document viewer", 
									Toast.LENGTH_SHORT).show();
			    		}   				    		

 } 
else if(cl==FileManager.TXT_LIST){
fileIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);   
	 if(item_ext.equalsIgnoreCase(".html")|| item_ext.equalsIgnoreCase(".htm")) fileIntent.setDataAndType(uri,"text/html"); 
else   	  fileIntent.setDataAndType(uri,"text/plain");   		

	 try {
			    			context.startActivity(fileIntent);
			    		} catch (ActivityNotFoundException e) {
			    			Toast.makeText(context,"Sorry, couldn't find a file viewer",Toast.LENGTH_SHORT).show();
			    		}   				    		
 }  

else  	Toast.makeText(context,"Sorry, this app couldn't determine the file type.",Toast.LENGTH_SHORT).show();	
	}

enum NatOrderCompar implements Comparator<PathItem> {
        INSTANCE;

        @Override
        public int compare(PathItem c1, PathItem c2) {
            return Long.compare(c1.getFileSize1(),c2.getFileSize1());
        }

        @Override
        public Comparator<PathItem> reversed() {
            return Comparator.reverseOrder();
        }
    }

}
