package com.github.bewketut.wifiScan;

public interface WifiScanCallback {
    void onScanResultsReady();
}
