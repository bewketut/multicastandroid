package com.github.bewketut.wifiDisconnect;

public enum DisconnectionErrorCode {
    COULD_NOT_GET_WIFI_MANAGER,
    COULD_NOT_GET_CONNECTIVITY_MANAGER,
    COULD_NOT_DISCONNECT,
}
